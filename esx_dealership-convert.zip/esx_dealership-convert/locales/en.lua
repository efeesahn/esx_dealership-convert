Locales ['en'] = {
  ['press_to_open'] = " ~r~E~w~ Basarak Galeriye Eris",
  ['enough_money'] = 'Paran Yok.',
  ['we_dont_vehicle'] = 'Stokta Kalmamış',
  ['car_dealer'] = 'Satıcı',
  ['rotate_keys'] = 'A ve D Basarak Aracı Dondur',
  ['testdrive'] = 'Kalan Suren '
 }
